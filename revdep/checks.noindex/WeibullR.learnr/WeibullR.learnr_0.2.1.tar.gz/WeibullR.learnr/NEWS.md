# WeibullR.learnr 0.2.1

## Minor Improvements and bug fixes
* Minor Improvements and bug fixes

# WeibullR.learnr 0.2

* Now with a new Reliability Testing tutorial called `TestR.learnr()` that covers Reliability Growth Analysis (RGA) and Accelerated Life Testing (ALT)
* Other minor improvements and bug fixes

# WeibullR.learnr 0.1.3

## Minor Improvements and bug fixes
* Update contact info
* Update citation

# WeibullR.learnr 0.1.2

## Initial release
* Weibullr.learnr function
